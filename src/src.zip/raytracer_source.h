#pragma once
const char* COMPUTE_SHADER_SOURCE = R"glsl(
#version 430 core
layout(local_size_x = 32, local_size_y = 32, local_size_z = 1) in;
layout(rgba32f, binding = 0) uniform image2D outImage;

// constants
const float c = 299792458.0;
const float G = 6.67430e-11;
const float PI = 3.141592653589793;

// raytracer uniforms
uniform float u_dLambda;
uniform int u_maxSteps;
uniform float u_escapeRadius;

// blackhole uniforms
uniform float u_RS;
uniform float u_AccretionRIN;
uniform float u_AccretionROUT;

// camera uniforms
uniform vec3 u_cameraPos;
uniform vec3 u_cameraTarget;

uniform bool u_isCameraMoving;
uniform float u_ScreenResolutionX;
uniform float u_ScreenResolutionY;

struct Object {
    vec4 positionRadius;
    vec4 color;
    vec4 padding;
};

bool InterceptObject(vec3 worldRayPos, Object object) {
    float dx = worldRayPos.x - object.positionRadius.x;
    float dy = worldRayPos.y - object.positionRadius.y;
    float dz = worldRayPos.z - object.positionRadius.z;

    float distanceSquared = dx * dx + dy * dy + dz * dz;
    return distanceSquared <= (object.positionRadius.w * object.positionRadius.w);
}

layout(std430, binding = 1) buffer ObjectBuffer {
    Object u_objects[]; // Flexible size array of Objects
};

uniform int u_numObjects;

struct Ray {
    vec3 cartesianPos;
    vec3 direction;

    float r, theta, phi;
    float dr, dtheta, dphi;
    float E;
    float L;
};

// RAY HELPER FUNCTIONS

void SphericalToCartesian(inout Ray ray)
{
    ray.cartesianPos.x = ray.r * sin(ray.theta) * cos(ray.phi);
    ray.cartesianPos.y = ray.r * sin(ray.theta) * sin(ray.phi);
    ray.cartesianPos.z = ray.r * cos(ray.theta);
}

void CartesianToSpherical(inout Ray ray)
{
    ray.r = length(ray.cartesianPos);
    if (ray.r < 1e-10) { // Avoid division by zero at the origin
        ray.theta = 0.0;
        ray.phi = 0.0;
        return;
    }
    ray.theta = acos(ray.cartesianPos.z / ray.r);
    ray.phi = atan(ray.cartesianPos.y, ray.cartesianPos.x);
}

// ACCRETION DISK INTERCEPT AND GET COLOR

vec4 GetAccretionDiskColor(float r)
{
    float r_ratio = max(1.0, r / u_AccretionRIN);
    float temp_proxy = pow(r_ratio, -0.75); // T ~ r^(-3/4)

    float intensity = temp_proxy * temp_proxy * 1.4; // Multiplier '5.0' for visual brightness

    // 3. Create a hot color gradient (Hot: White/Blue -> Cool: Red/Orange)
    // The hottest areas are blue-white in high-energy visualization.

    vec4 hot_color = mix(
        vec4(0.8, 0.5, 0.0, 1.0),
        vec4(0.8, 0.0, 0.0, 1.0),
        (r - u_AccretionRIN) / (u_AccretionROUT - u_AccretionRIN)
    );

    return clamp(hot_color * intensity, 0.0, 1.0);
}

// RK4 AND CARTESIAN EQUATIONS

Ray GetInitialRay(vec2 pixelPos)
{
    Ray initialRay;

    // Normalized Device Coords
    float ndcX = ((pixelPos.x + 0.5f) / u_ScreenResolutionX) * 2.0f - 1.0f;
    float ndcY = ((pixelPos.y + 0.5f) / u_ScreenResolutionY) * 2.0f - 1.0f;

    float aspect = u_ScreenResolutionX / u_ScreenResolutionY;
    const float HALF_FOV = radians(30.0f);
    float tanHalfFov = tan(HALF_FOV);

    float px = ndcX * aspect * tanHalfFov;
    float py = -ndcY * tanHalfFov; // flip Y

    // Standard camera space vectors
    vec3 forward = normalize(u_cameraTarget - u_cameraPos);
    vec3 worldUp = vec3(0.0, 1.0, 0.0);

    // Handle edge case: forward nearly parallel to worldUp
    vec3 right;
    if (abs(dot(forward, worldUp)) > 0.999) {
        worldUp = vec3(0.0, 0.0, 1.0);
    }

    right = normalize(cross(forward, worldUp));
    vec3 up = normalize(cross(right, forward));

    vec3 dir = normalize(forward + px * right + py * -up);
    initialRay.direction = dir;
    initialRay.cartesianPos = u_cameraPos;

    vec3 relPos = u_cameraPos;

    // get initial spherical coords

    initialRay.r = length(relPos);
    if (initialRay.r < 1e-10)
    {
        initialRay.theta = 0.0;
        initialRay.phi = 0.0;
    }
    else
    {
        initialRay.theta = acos(clamp(relPos.z / initialRay.r, -1.0, 1.0));
        initialRay.phi = atan(relPos.y, relPos.x);
    }

    // --- 3. Calculate initial derivatives (dr, dtheta, dphi) ---
    float dx = dir.x, dy = dir.y, dz = dir.z;
    float r = initialRay.r;
    float theta = initialRay.theta;
    float phi = initialRay.phi;

    initialRay.dr = sin(theta) * cos(phi) * dx + sin(theta) * sin(phi) * dy + cos(theta) * dz;
    initialRay.dtheta = (cos(theta) * cos(phi) * dx + cos(theta) * sin(phi) * dy - sin(theta) * dz) / r;

    float r_sin_theta = r * sin(theta);
    if (abs(r_sin_theta) < 1e-10)
    {
        initialRay.dphi = 0.0;
    }
    else
    {
        initialRay.dphi = (-sin(phi) * dx + cos(phi) * dy) / r_sin_theta;
    }

    // angular velocity/momentum
    initialRay.L = r * r * sin(theta) * initialRay.dphi;
    // Energy (E) 
    float f = 1.0 - u_RS / r;

    // This is derived from the null geodesic condition: g_mu_nu * p^mu * p^nu = 0
    float radial_term_sq = initialRay.dr * initialRay.dr;
    float angular_term_f = f * r * r * (initialRay.dtheta * initialRay.dtheta + sin(theta) * sin(theta) * initialRay.dphi * initialRay.dphi);

    float E_sq = radial_term_sq + angular_term_f;
    if (E_sq < 0.0) E_sq = 0.0;

    initialRay.E = sqrt(E_sq);

    return initialRay;
}

void GetDerivatives(const Ray ray, out float d2r, out float d2theta, out float d2phi)
{
    float r = ray.r, theta = ray.theta;
    float dr = ray.dr, dtheta = ray.dtheta, dphi = ray.dphi;
    float rs = u_RS;


    float f = 1.0 - rs / r;
    float dt_dL;

    // Check for near event horizon
    if (abs(f) < 1e-6) {
        dt_dL = 0.0;
        d2r = d2theta = d2phi = 0.0;
        return;
    }
    else {
        // dt/d\lambda = E / f(r). This is correct for the equation of motion.
        dt_dL = ray.E / f;
    }

    // Geodesic Equation for r: d^2 r / d\lambda^2
    d2r = -(rs / (2.0 * r * r)) * f * dt_dL * dt_dL
        + (rs / (2.0 * r * r * f)) * dr * dr
        + r * (dtheta * dtheta + sin(theta) * sin(theta) * dphi * dphi);

    // Geodesic Equation for theta: d^2 theta / d\lambda^2
    d2theta = -2.0 * dr * dtheta / r
        + sin(theta) * cos(theta) * dphi * dphi;

    // Geodesic Equation for phi: d^2 phi / d\lambda^2
    float sin_theta = sin(theta);
    // Avoid pole singularity (theta = 0 or theta = PI)
    if (abs(sin_theta) < 1e-6) {
        d2phi = 0.0;
    }
    else {
        d2phi = -2.0 * dr * dphi / r
            - 2.0 * cos(theta) / sin_theta * dtheta * dphi;
    }
}

void RK4STEP(inout Ray ray)
{
    float half_dL = 0.5 * u_dLambda;
    float sixth_dL = u_dLambda / 6.0;

    // --- K1 (Derivatives at start of interval) ---
    Ray k1_ray = ray;
    float k1_d2r, k1_d2theta, k1_d2phi;
    GetDerivatives(k1_ray, k1_d2r, k1_d2theta, k1_d2phi);

    // --- K2 (Derivatives at midpoint using K1) ---
    Ray k2_ray;
    k2_ray.E = ray.E; k2_ray.L = ray.L; // Conserved quantities

    k2_ray.r = ray.r + half_dL * k1_ray.dr;
    k2_ray.theta = ray.theta + half_dL * k1_ray.dtheta;
    k2_ray.phi = ray.phi + half_dL * k1_ray.dphi;

    k2_ray.dr = ray.dr + half_dL * k1_d2r;
    k2_ray.dtheta = ray.dtheta + half_dL * k1_d2theta;
    k2_ray.dphi = ray.dphi + half_dL * k1_d2phi;

    float k2_d2r, k2_d2theta, k2_d2phi;
    GetDerivatives(k2_ray, k2_d2r, k2_d2theta, k2_d2phi);

    // --- K3 (Derivatives at midpoint using K2) ---
    Ray k3_ray;
    k3_ray.E = ray.E; k3_ray.L = ray.L;

    k3_ray.r = ray.r + half_dL * k2_ray.dr;
    k3_ray.theta = ray.theta + half_dL * k2_ray.dtheta;
    k3_ray.phi = ray.phi + half_dL * k2_ray.dphi;

    k3_ray.dr = ray.dr + half_dL * k2_d2r;
    k3_ray.dtheta = ray.dtheta + half_dL * k2_d2theta;
    k3_ray.dphi = ray.dphi + half_dL * k2_d2phi;

    float k3_d2r, k3_d2theta, k3_d2phi;
    GetDerivatives(k3_ray, k3_d2r, k3_d2theta, k3_d2phi);

    // --- K4 (Derivatives at end of interval using K3) ---
    Ray k4_ray;
    k4_ray.E = ray.E; k4_ray.L = ray.L;

    k4_ray.r = ray.r + u_dLambda * k3_ray.dr;
    k4_ray.theta = ray.theta + u_dLambda * k3_ray.dtheta;
    k4_ray.phi = ray.phi + u_dLambda * k3_ray.dphi;

    k4_ray.dr = ray.dr + u_dLambda * k3_d2r;
    k4_ray.dtheta = ray.dtheta + u_dLambda * k3_d2theta;
    k4_ray.dphi = ray.dphi + u_dLambda * k3_d2phi;

    float k4_d2r, k4_d2theta, k4_d2phi;
    GetDerivatives(k4_ray, k4_d2r, k4_d2theta, k4_d2phi);

    // --- Final update (Weighted average of slopes) ---

    // Update positions (r, theta, phi) using velocities (dr, dtheta, dphi)
    ray.r += sixth_dL * (k1_ray.dr + 2.0 * k2_ray.dr + 2.0 * k3_ray.dr + k4_ray.dr);
    ray.theta += sixth_dL * (k1_ray.dtheta + 2.0 * k2_ray.dtheta + 2.0 * k3_ray.dtheta + k4_ray.dtheta);
    ray.phi += sixth_dL * (k1_ray.dphi + 2.0 * k2_ray.dphi + 2.0 * k3_ray.dphi + k4_ray.dphi);

    // Update velocities (dr, dtheta, dphi) using second derivatives (d2r, d2theta, d2phi)
    ray.dr += sixth_dL * (k1_d2r + 2.0 * k2_d2r + 2.0 * k3_d2r + k4_d2r);
    ray.dtheta += sixth_dL * (k1_d2theta + 2.0 * k2_d2theta + 2.0 * k3_d2theta + k4_d2theta);
    ray.dphi += sixth_dL * (k1_d2phi + 2.0 * k2_d2phi + 2.0 * k3_d2phi + k4_d2phi);
}

vec4 TraceAndGetColor(Ray initialRay)
{
    Ray currentRay = initialRay;
    Ray prevRay = initialRay;

    for (int i = 0; i < u_maxSteps; i++)
    {
        prevRay = initialRay;

        RK4STEP(currentRay);
        SphericalToCartesian(currentRay);

        float prevY = prevRay.r * sin(prevRay.theta) * sin(prevRay.phi);
        // Current position Y-coordinate
        float currentY = currentRay.r * sin(currentRay.theta) * sin(currentRay.phi);

        // 2. Check if the ray crossed the equatorial plane (y-coordinate changed sign)
        if (prevY * currentY < 0.0)
        {
            // Ray crossed the plane y=0. Find the intersection point by linear interpolation (LOD step is small)
            // t = |y_prev| / (|y_prev| + |y_current|)
            float t = abs(prevY) / (abs(prevY) + abs(currentY));

            // Interpolate the spherical radius 'r' at the crossing point
            float intersection_r = mix(prevRay.r, currentRay.r, t);

            // 3. Check if the intersection radius is within the disk's bounds
            if (intersection_r >= u_AccretionRIN && intersection_r <= u_AccretionROUT)
            {
                // Hit the accretion disk
                return GetAccretionDiskColor(intersection_r);
            }
        }

        if (currentRay.r > u_escapeRadius)
        {
            return vec4(0.0, 0.0, 0.0, 0.0);
        }

        if (currentRay.r <= u_RS)
        {
            return vec4(0.0, 0.0, 0.0, 1.0);
        }

        for (int j = 0; j < u_numObjects; j++)
        {
            if (InterceptObject(currentRay.cartesianPos, u_objects[j]))
            {
                vec4 col = u_objects[j].color / 255.0;
                return vec4(col.x, col.y, col.z, 1.0);
            }
        }
    }

    // Default return color if max steps reached (black)
    return vec4(0.0, 0.0, 0.0, 0.0);
}

void main()
{
    float width = u_isCameraMoving ? u_ScreenResolutionX : u_ScreenResolutionX;
    float height = u_isCameraMoving ? u_ScreenResolutionX : u_ScreenResolutionY;

    ivec2 pixelCoords = ivec2(gl_GlobalInvocationID.xy);
    if (pixelCoords.x >= width || pixelCoords.y >= height)
        return;

    Ray initialRay = GetInitialRay(vec2(pixelCoords));

    vec4 color = TraceAndGetColor(initialRay);

    imageStore(outImage, pixelCoords, color);
    return;
}
)glsl";
